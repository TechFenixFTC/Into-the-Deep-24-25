package org.firstinspires.ftc.teamcode.subsystems.Vision;

public class Webcam {
}
