package org.firstinspires.ftc.teamcode.subsystems.common.Garra;

public enum GarraOpeningStates {
    OPEN,
    CLOSED
}
