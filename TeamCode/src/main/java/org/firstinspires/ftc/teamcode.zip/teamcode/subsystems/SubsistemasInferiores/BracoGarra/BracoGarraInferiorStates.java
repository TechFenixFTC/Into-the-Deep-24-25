package org.firstinspires.ftc.teamcode.subsystems.SubsistemasInferiores.BracoGarra;

public enum BracoGarraInferiorStates {
    READY_TOINTAKE,
    INTAKE,
    TRASNFER,
    INITIAL,
}
