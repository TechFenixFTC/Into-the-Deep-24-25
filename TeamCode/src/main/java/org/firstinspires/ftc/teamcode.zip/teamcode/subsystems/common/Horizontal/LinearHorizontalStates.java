package org.firstinspires.ftc.teamcode.subsystems.common.Horizontal;

public enum LinearHorizontalStates {
    EXTENDED,
    RETRACTED,
    INTERMEDIATE,
}
