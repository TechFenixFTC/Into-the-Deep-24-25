package org.firstinspires.ftc.teamcode.agregadoras.agregadorasSubsistemas.Inferior;

public enum UnderGrounSubystemStates {
    READY_TOINTAKE,
    INTAKE,
    TRASNFER,
    INITIAL,
}
