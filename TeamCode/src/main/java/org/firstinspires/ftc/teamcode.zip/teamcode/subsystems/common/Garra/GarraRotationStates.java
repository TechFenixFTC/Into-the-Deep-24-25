package org.firstinspires.ftc.teamcode.subsystems.common.Garra;

public enum GarraRotationStates {

    PERPENDICULAR,
    PARALELA
}
