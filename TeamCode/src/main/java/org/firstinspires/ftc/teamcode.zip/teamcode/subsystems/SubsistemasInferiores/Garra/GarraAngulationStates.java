package org.firstinspires.ftc.teamcode.subsystems.SubsistemasInferiores.Garra;

public enum GarraAngulationStates {

    INTAKE,
    READYTO_INTAKE,
    TRANSFER,
}
