package org.firstinspires.ftc.teamcode.subsystems.SubsistemasSuperiores.BracoGarra;

public enum BracoGarraStates {
        Outtake,
        Intake,
        Initial,
        Intemediate,

        IntakeChamber,
        OuttakeChamber,



}
