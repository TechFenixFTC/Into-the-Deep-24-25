package org.firstinspires.ftc.teamcode.common.verifys;

public class vertexVerifys {
    // colocar todas as funções aqui mesmo
    // ou separa cada função de verify -> uma classe - um subsistema
    // ?? 
}
