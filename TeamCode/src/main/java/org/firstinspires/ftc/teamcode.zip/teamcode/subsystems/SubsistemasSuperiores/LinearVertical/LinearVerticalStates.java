package org.firstinspires.ftc.teamcode.subsystems.SubsistemasSuperiores.LinearVertical;

public enum LinearVerticalStates {
    Initial,
    Intake,
    Outtake,
    Intermediate,
    OuttakeChamber,
    IntakeChamber,
}
