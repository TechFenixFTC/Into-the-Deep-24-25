package org.firstinspires.ftc.teamcode.agregadoras;

import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.ftc.Encoder;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.roadrunner.MecanumDrive;
import org.firstinspires.ftc.teamcode.subsystems.Vertex.Garra;
import org.firstinspires.ftc.teamcode.subsystems.Vertex.LinearHorizontal;
import org.firstinspires.ftc.teamcode.subsystems.Vertex.LinearVertical;

import java.util.ArrayList;
import java.util.List;
public class V2 {
    // Attributes
    public MecanumDrive md;
    public Telemetry telemetry;
    List<Encoder> leftEncs = new ArrayList<>(), rightEncs = new ArrayList<>();
    public Vertex intakeOutake;
    HardwareMap hardwaremap;


    public V2(HardwareMap hardwareMap, Telemetry telemetry) {

        md = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));



        // -Controle de leituras- \\
        List<LynxModule> allHubs = hardwareMap.getAll(LynxModule.class);
        for (LynxModule hub : allHubs) {
            hub.setBulkCachingMode(LynxModule.BulkCachingMode.AUTO);
        }

        this.hardwaremap = hardwareMap;

        this.telemetry = telemetry;
        this.intakeOutake = new Vertex(hardwareMap, telemetry);

    }

    /*
    aqui preciso colocar as ações prontas do chassi (e toda lógica pra isso funcionar) além de ações que envolvem o v2
    todo: gotoBasket
    todo: goToSubmersible
    todo: goNearTheObservationZone
     */
    private double getVoltage() { return hardwaremap.voltageSensor.iterator().next().getVoltage(); }

}
