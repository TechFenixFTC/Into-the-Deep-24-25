package org.firstinspires.ftc.teamcode.opmode.v2_opModes;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.agregadoras.V2;

@Config
@Autonomous(name = "AutonomoA5", group = "Autonomous")
public class AutonomoA5 extends LinearOpMode {

    @Override
    public void runOpMode() {
        Pose2d initialPose = new Pose2d(-34, -61, Math.toRadians(172));
        V2 robot = new V2(hardwareMap, telemetry);
        robot.md.pose = initialPose;
        robot.intakeOutake.braco.autonomo = true;


        Action movesSample1 = robot.md.actionBuilder(robot.md.pose)
           /* sample 1 */
                //.splineToLinearHeading(new Pose2d(-25, -67,  Math.toRadians(3)), Math.toRadians(30))
                .lineToX( -40)
                .build();


        Action moveSample2 = robot.md.actionBuilder(robot.md.pose)
           /* sample 2 */
                .setTangent(Math.toRadians(90))
                .splineToLinearHeading(new Pose2d(-42, -42,  Math.toRadians(90)), Math.toRadians(90))

                .build();

        Action moveSample3 =robot.md.actionBuilder(robot.md.pose)
                .setTangent(Math.toRadians(90))
                .splineToLinearHeading(new Pose2d(-54, -42,  Math.toRadians(90)), Math.toRadians(90))

                .build();

         /*


                .setTangent(Math.toRadians(180))
                .splineToLinearHeading(new Pose2d(-58, -50,  Math.toRadians(90)), Math.toRadians(180))

                .setTangent(Math.toRadians(0))
                .splineToLinearHeading(new Pose2d(-50, -50,  Math.toRadians(-135)), Math.toRadians(-135))

                .setTangent(Math.toRadians(0))
                .splineToLinearHeading(new Pose2d(-49, -25,  Math.toRadians(180)), Math.toRadians(135))

                .setTangent(Math.toRadians(0))
                .splineToLinearHeading(new Pose2d(-50, -50,  Math.toRadians(-135)), Math.toRadians(-135))

                .setTangent(Math.toRadians(90))
                .splineToLinearHeading(new Pose2d(-34, -12,  Math.toRadians(0)), Math.toRadians(0))
                */
        Action depositSample =
                robot.md.actionBuilder(robot.md.pose)
                        .setTangent(Math.toRadians(90))
                        .splineToLinearHeading(new Pose2d(-48, -45,  Math.toRadians(-135)), Math.toRadians(90))

                        .build();


        Action sample1 = new SequentialAction(

                new ParallelAction(
                        movesSample1,
                        robot.intakeOutake.linearVertical.ElevadorGoTo(2800),
                        robot.intakeOutake.braco.goToBasketOutake(0, 0),
                        robot.intakeOutake.garra.rotacionarGarraParaPosicaoParalela()
                ),
                robot.intakeOutake.linearHorizontal.extenderNemTanto(0, 0),
                //movesSample1,
                robot.intakeOutake.garra.abrirGarra(),
                robot.md.actionBuilder(robot.md.pose).waitSeconds(0.3).build(),
                robot.intakeOutake.braco.goToStored(0,0),
                robot.intakeOutake.linearHorizontal.recolher(0, 0)
                //robot.intakeOutake.linearVertical.ElevadorGoTo(0)
                //robot.md.actionBuilder(robot.md.pose).waitSeconds(0.5 ).build()

        );
        Action sample2 = new SequentialAction(
                new ParallelAction(
                moveSample2,
                robot.intakeOutake.garra.abrirGarra()
        ),
        new ParallelAction(
                robot.intakeOutake.linearVertical.ElevadorGoTo(480),
                robot.intakeOutake.garra.rotacionarGarraParaPosicaoParalela(),
                robot.intakeOutake.linearHorizontal.extender(0,0)
        ),
                robot.intakeOutake.braco.goToIntakePositon(0,0),
                robot.md.actionBuilder(robot.md.pose).waitSeconds(0.4).build(),
                robot.intakeOutake.linearVertical.ElevadorGoTo(-120),
                robot.intakeOutake.linearVertical.ElevadorGoTo(10),
                robot.md.actionBuilder(robot.md.pose).waitSeconds(0.2).build(),
                robot.intakeOutake.garra.fecharGarra(),
                robot.md.actionBuilder(robot.md.pose).waitSeconds(0.2).build(),
                robot.intakeOutake.linearVertical.ElevadorGoTo(480),
                robot.intakeOutake.braco.goToStored(0,0),
                robot.intakeOutake.linearHorizontal.recolher(0, 0),
                robot.md.actionBuilder(robot.md.pose).waitSeconds(0.5 ).build(),
                depositSample,

                new ParallelAction(
                        robot.intakeOutake.linearVertical.ElevadorGoTo(2700),
                        robot.intakeOutake.braco.goToBasketOutake(0, 0)
                        //robot.intakeOutake.garra.rotacionarGarraParaPosicaoPerpendicular()
                ),
                robot.intakeOutake.linearHorizontal.extender(0, 0),
                //movesSample1,
                robot.intakeOutake.garra.abrirGarra(),
                robot.md.actionBuilder(robot.md.pose).waitSeconds(0.3).build()
        );



        waitForStart();

        Actions.runBlocking(
                            new SequentialAction(
                                    sample1,
                                    sample2,
                                    robot.intakeOutake.braco.goToStored(0,0),
                                    robot.intakeOutake.linearHorizontal.recolher(0,0),
                                    moveSample3,
                                    new ParallelAction(
                                            robot.intakeOutake.linearVertical.ElevadorGoTo(680),
                                            robot.intakeOutake.garra.rotacionarGarraParaPosicaoParalela(),
                                            robot.intakeOutake.linearHorizontal.extender(0,0)
                                    ),
                                    robot.intakeOutake.braco.goToIntakePositon(0,0),
                                    robot.intakeOutake.linearVertical.ElevadorGoTo(10),
                                    robot.intakeOutake.garra.fecharGarra(),
                                    robot.md.actionBuilder(robot.md.pose).waitSeconds(0.35).build(),
                                    robot.intakeOutake.linearVertical.ElevadorGoTo(480),
                                    robot.intakeOutake.braco.goToStored(0,0),
                                    robot.intakeOutake.linearHorizontal.recolher(0, 0),
                                    robot.md.actionBuilder(robot.md.pose)
                                            .setTangent(Math.toRadians(90))
                                            .splineToLinearHeading(new Pose2d(-48, -45,  Math.toRadians(-135)), Math.toRadians(90))

                                            .build(),

                                    new ParallelAction(
                                            robot.intakeOutake.linearVertical.ElevadorGoTo(2700),
                                            robot.intakeOutake.braco.goToBasketOutake(0, 0),
                                            robot.intakeOutake.garra.rotacionarGarraParaPosicaoPerpendicular()
                                    ),
                                    robot.intakeOutake.linearHorizontal.extenderNemTanto(0, 0),
                                    //movesSample1,
                                    robot.intakeOutake.garra.abrirGarra(),
                                    robot.md.actionBuilder(robot.md.pose).waitSeconds(0.3).build(),
                                    robot.intakeOutake.braco.goToStored(0,0),
                                    robot.intakeOutake.linearHorizontal.recolher(0, 0),
                                    robot.intakeOutake.linearVertical.ElevadorGoTo(0),
                                    robot.md.actionBuilder(robot.md.pose)
                                            .setTangent(Math.toRadians(90))
                                            .splineToLinearHeading(new Pose2d(-30, -10,  Math.toRadians(0)), Math.toRadians(0))

                                            .build()




                            )

        );

    }
}