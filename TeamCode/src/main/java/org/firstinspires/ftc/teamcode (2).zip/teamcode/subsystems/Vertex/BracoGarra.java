package org.firstinspires.ftc.teamcode.subsystems.Vertex;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantAction;
import com.arcrobotics.ftclib.controller.PIDController;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@Config
public class BracoGarra {
    public Servo servoBracoDaGarra;
    public DcMotorEx motorBracoGarra;
    public int targetPosition = 0;
    public static double kp = 0.0003, ki = 0, kd = 0.00, kff = 0, l = 0.03;
    public double correcao = 0;
    private final double ticks_in_degree = 8192 / 360;
    public  boolean
            needToGoToIntake = false,
            needToGoToStored = false,
            needToGoToBasketOutake = false,
            needToGoToChamberOutake = false,
            needToGoToIntermadiate = false,
            autonomo = false;
    public double when = 0;


    public BracoGarra(HardwareMap hardwareMap) {
        this.servoBracoDaGarra = hardwareMap.get(Servo.class, "porta1");

        servoBracoDaGarra.getController().pwmDisable();
        motorBracoGarra = (DcMotorEx) hardwareMap.get(DcMotor.class, "bracin");
        motorBracoGarra.setDirection(DcMotorSimple.Direction.REVERSE);
        motorBracoGarra.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        reset();
    }

    public void reset() {
        motorBracoGarra.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorBracoGarra.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }




    public int getPosition() {
        return -motorBracoGarra.getCurrentPosition();
    }

    public double controladorDePosicao() {

        // FeedForward

        double ff = targetPosition  * kff;
        if (!(targetPosition > 2000 && targetPosition < 3000)) {
            ff = 0;
        }

        //KP
        double p = kp;
        if (targetPosition > 4000 && getPosition() < targetPosition && Math.abs(motorBracoGarra.getVelocity()) > 10000) {
            p = p/3.1;
            if(Math.abs(motorBracoGarra.getVelocity()) > 10000){
                p = p / 5.2;
            }
        }
        if ( (targetPosition < 4000 && getPosition() > 4000) || targetPosition > 4500 && getPosition() > 5500) {
           // p = p * 4;
        }



        //Cria o Controlador PID
        PIDController controller = new PIDController(kp, 0, kd);
        controller.setPID(kp, 0, kd);

        //Calcular correção
        double pid = controller.calculate(this.getPosition(), targetPosition);

        // LL
        double ll = (Math.abs(controller.getPositionError()) / controller.getPositionError() * l);
        if( Math.abs(controller.getPositionError()) < 100) {
            ll = 0;
        }
        if( Math.abs(controller.getPositionError()) > 100 && targetPosition > 5000) {
           ll = 0.1;
        }

        if( Math.abs(controller.getPositionError()) > 200 && (targetPosition > 500 && targetPosition < 3800) && getPosition() > 4500) {
            ll = Math.abs(controller.getPositionError()) / controller.getPositionError() *  0.4;
        }
        if( Math.abs(controller.getPositionError()) > 100 &&  getPosition() < 1800) {
            ll = Math.abs(controller.getPositionError()) / controller.getPositionError() *  0.27;
        }

        this.correcao = pid + ff + ll;
        this.motorBracoGarra.setPower(this.correcao);

        return controller.getPositionError();

    }



    public Action goToIntakePositon(double runtime, double delay) {
        if ( delay > 0) {
            when = runtime + delay;
            needToGoToIntake = true;
            return new InstantAction(() -> {});
        }
        return new Action() {
            int margin;
            boolean started = false;
            ElapsedTime time = new ElapsedTime();
            boolean condition;
            @Override
            public boolean run(@NonNull TelemetryPacket telemetryPacket) {
                if(!started) {
                    time.reset();
                    targetPosition = 5402;
                    if(getPosition() > 2000 && !autonomo) {
                        targetPosition = 5900;
                    }
                    started = true;
                }


                margin  = 500;

                double positionError = controladorDePosicao();
                condition = Math.abs(positionError) > margin;
                if (!condition || time.time() > 1.2) {
                    motorBracoGarra.setPower(0.05);
                    return false;
                }
                return condition;
            }

        };
    }

    public Action goToStored(double runtime, double delay) {
        if ( delay > 0) {
            when = runtime + delay;
            needToGoToStored = true;
            return new InstantAction(() -> {});
        }
        return new Action() {
            int margin;
            boolean started = false;
            boolean condition = true;
            ElapsedTime time = new ElapsedTime();

            @Override
            public boolean run(@NonNull TelemetryPacket telemetryPacket) {
                if (!started) {
                    time.reset();
                    targetPosition = -1000;
                    started = true;
                }


                margin = 200;
                double positionError = controladorDePosicao();

                condition = (time.time() > 0.4 && Math.abs(motorBracoGarra.getVelocity()) < 15);
                if (condition) {
                    reset();
                    targetPosition = 0;
                }
                return !condition;
            }
        };
    }
    public Action goToIntermediatePosition(double runtime, double delay) {
        if(delay > 0){
            when = runtime + delay;
            needToGoToIntermadiate = true;
            return new InstantAction(() -> {});
        }
        return  new Action() {
            int margin;
            boolean started = false;
            ElapsedTime time = new ElapsedTime();

            @Override
            public boolean run(@NonNull TelemetryPacket telemetryPacket) {
                if (!started) {
                    time.reset();
                    targetPosition = 2850;
                    started = true;
                }


                margin = 100;

                double positionError = controladorDePosicao();
                return Math.abs(positionError) > margin;
            }
        };
    }
    public Action goToBasketOutake(double runtime, double delay) {
        if ( delay > 0) {
            when = runtime + delay;
            needToGoToBasketOutake = true;
            return new InstantAction(() -> {});
        }
        return  new Action() {
            int margin;
            boolean started = false;
            ElapsedTime time = new ElapsedTime();
            boolean condition;
            @Override
            public boolean run(@NonNull TelemetryPacket telemetryPacket) {
                if (!started) {
                    time.reset();
                    targetPosition = 1700;
                    if(autonomo) targetPosition = targetPosition + 100;

                    if(getPosition() < 1000 && !autonomo) {
                        targetPosition = 2300;
                    }


                    started = true;
                }


                margin = 200;

                double positionError = controladorDePosicao();
                condition = Math.abs(positionError) > margin;
                if (!condition) {
                    motorBracoGarra.setPower(-0.015);
                    targetPosition = 1500;
                }

                return condition;
            }
        };
    }

    public Action goToBasketOutakeAut() {
        return goToBasketOutake(0, 0);
    }

    public Action goToChamberOutake(double runtime, double delay) {
        if ( delay > 0) {
            when = runtime + 0.7;
            needToGoToStored = true;
            return new InstantAction(() -> {});
        }

        return goToIntermediatePosition(0, 0);
    }


    public Action handleBracoTeleop(double runtime) {
        if ( needToGoToIntake && runtime >= when) {
            needToGoToIntake = false;
            return goToIntakePositon(runtime, 0);
        }

        if ( needToGoToBasketOutake && runtime >= when) {
            needToGoToBasketOutake = false;
            return goToBasketOutake(runtime, 0);
        }

        if ( needToGoToStored && runtime >= when) {
            needToGoToStored = false;
            return goToStored(runtime, 0);
        }

        if ( needToGoToIntermadiate && runtime >= when) {
            needToGoToIntermadiate  = false;
            return goToIntermediatePosition(runtime, 0);
        }

        return new InstantAction(() -> {});
    }
    public void upBraco(double quanto) {

        targetPosition = targetPosition + 150 ;
        servoBracoDaGarra.setPosition(targetPosition);

    }

    public void downBraco(double quanto) {
        targetPosition = targetPosition - 150;
        servoBracoDaGarra.setPosition(targetPosition);
}



}