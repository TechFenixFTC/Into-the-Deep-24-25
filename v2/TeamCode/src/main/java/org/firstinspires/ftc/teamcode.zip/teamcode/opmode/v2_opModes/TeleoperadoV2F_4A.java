package org.firstinspires.ftc.teamcode.opmode.v2_opModes;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.PoseVelocity2d;
import com.acmerobotics.roadrunner.Vector2d;
import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.arcrobotics.ftclib.gamepad.GamepadKeys;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.agregadoras.V2;
import org.firstinspires.ftc.teamcode.subsystems.Vertex.BracoGarra;

import java.util.ArrayList;
import java.util.List;

@TeleOp(name="Teleoperado V2f")
public class TeleoperadoV2F_4A extends OpMode {

    V2 robot;
    private boolean bracoOkToGo = false;
    FtcDashboard dashboard = FtcDashboard.getInstance();
    Telemetry dashboardTelemetry = dashboard.getTelemetry();
    private List<Action> runningActions = new ArrayList<>();
    public double drive = 0, strafe = 0, turn = 0;
    private  double timeout = 0, delay = 0.3;
    GamepadEx gamepadEx1;
    public ColorSensor colorSensor;

    //rampa de aceleração
    double CurrentSpeed;
    double MaxSpeed= 1;
    double SmAcceleration = 0.04;

    // cria uma lista de servos para serem testados
    List<Servo> servos = new ArrayList<>(5);
    String[] nomesServosTestados  = {"porta0", "porta1", "porta2", "porta4", "porta5"};

    double[] angulosServosTestado = {0.5, 0.5, 0.5, 0.5, 0.5};
    int portaServoSendoTestado = 0;
    int blue, green, red;
    double cooldownChangePortaServo = 0;
    @Override
    public  void  init() {

        colorSensor = hardwareMap.get(ColorSensor.class, "colorSensor");

        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        robot = createRobot(hardwareMap);
        gamepadEx1 = new GamepadEx(gamepad2);



        for (int i = 0; i < 4; i++) {
            servos.add(hardwareMap.get(Servo.class, nomesServosTestados[i]));
        }

    }

    @Override
    public void  loop() {

        red = colorSensor.red();
        green = colorSensor.green();

        /*=============*\
        |      Modo     |
        \*=============*/
        if(gamepad1.start) {
            changeMode();
        }
        /*=============*\
        |    Chassi     |
        \*=============*/
        robotCentricDrive(robot);
        //telemetry.addData("X", robot.md.pose.position.x);
        //telemetry.addData("Y", robot.md.pose.position.y);

        /*=======================*\
        |      INTAKE-OUTAKE      |
        \*=======================*/
        if (gamepadEx1.getButton(GamepadKeys.Button.BACK) ) { /* reset */
            robot.intakeOutake.linearHorizontal.targetPositionLinearHorizontal = 0;
            robot.intakeOutake.linearHorizontal.motorLinearHorizontal.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            robot.intakeOutake.linearHorizontal.motorLinearHorizontal.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        }


        if (gamepadEx1.getButton(GamepadKeys.Button.B) && timeout <= getRuntime()){
            timeout = getRuntime() + delay;
            if((robot.intakeOutake.linearVertical.targetPosition > 2500)) {

                runningActions.add(robot.intakeOutake.braco.goToStored(getRuntime(), 0));

                // segunda ação
                runningActions.add(robot.intakeOutake.linearHorizontal.recolher(getRuntime(), 0));

                // terceira ação
                robot.intakeOutake.linearVertical.changeTarget(getRuntime(), 0.5, 0);
            }
            else {

                robot.intakeOutake.linearVertical.targetPosition = 0;

                // primeira ação
                runningActions.add(robot.intakeOutake.braco.goToStored(getRuntime(),0.5));

                runningActions.add(robot.intakeOutake.linearHorizontal.recolher(getRuntime(), 0.3));

                //runningActions.add(robot.intakeOutake.braco.goToBasketOutake(getRuntime(), 1));
                //robot.intakeOutake.linearVertical.changeTarget(getRuntime(), 0.9, 0);
              //  telemetry.addLine("AAAAAA");
            }
        }



        if (gamepadEx1.getButton(GamepadKeys.Button.X)  && timeout <= getRuntime()) {
            timeout = getRuntime() + delay;
            if(!(robot.intakeOutake.linearVertical.targetPosition > 2500)){

                runningActions.add(robot.intakeOutake.linearHorizontal.extender(getRuntime(), 0));
                //robot.intakeOutake.linearVertical.targetPosition = 280;
                robot.intakeOutake.linearVertical.changeTarget(getRuntime(),0.2,280);
                // 3
                runningActions.add(robot.intakeOutake.braco.goToIntakePositon(getRuntime(), 0.2));

                runningActions.add(robot.intakeOutake.garra.abrirGarra());
            }

        }

        if (gamepadEx1.getButton(GamepadKeys.Button.Y)  && timeout <= getRuntime())          {
            timeout = getRuntime() + delay;
            /* GoToCanOutakeState */
            robot.intakeOutake.linearVertical.targetPosition = 2800;
            // robot.intakeOutake.linearHorizontal.extender(getRuntime(), 0);
            runningActions.add(robot.intakeOutake.linearHorizontal.recolher(getRuntime(), 0.3));
            runningActions.add(robot.intakeOutake.braco.goToBasketOutake(getRuntime(), 0));

            // robot.intakeOutake.braco.targetPosition = 5200;
        }

        if(gamepadEx1.getButton(GamepadKeys.Button.A)  && timeout <= getRuntime()){
            timeout = getRuntime() + delay;
            robot.intakeOutake.linearVertical.targetPosition = 30;
            runningActions.add(robot.intakeOutake.garra.fecharGarra());
            runningActions.add(robot.intakeOutake.braco.goToIntermediatePosition(getRuntime(),0.4));
            robot.intakeOutake.linearVertical.changeTarget(getRuntime(), 0.65, 280);

            runningActions.add(robot.intakeOutake.linearHorizontal.recolher(getRuntime(), 0.7));
        }


        /*=======================*\
        |    Linear Vertical      |
        \*=======================*/
        //telemetry.addData("Posição Alvo vertical", robot.intakeOutake.linearVertical.targetPosition);
        //telemetry.addData("Posição vertical", robot.intakeOutake.linearVertical.motorR.getCurrentPosition());
        /* Sobe o Linear Vertical */
        if (gamepadEx1.getButton(GamepadKeys.Button.DPAD_UP))    { robot.intakeOutake.linearVertical.upSetPoint();  }
        /* Desce o Linear Vertical */
        if (gamepadEx1.getButton(GamepadKeys.Button.DPAD_DOWN) ) {  robot.intakeOutake.linearVertical.downSetPoint();  }

        if(gamepad2.right_stick_button) {
            robot.intakeOutake.linearVertical.reset();
        }
        /* Executa o controlador do Linear Vertical*/
        robot.intakeOutake.linearVertical.handleElevadorTeleop(telemetry, getRuntime());

        /*=======================*\
        |    Linear Horizonal     |
        \*=======================*/
        if(gamepad2.dpad_right) {
            robot.intakeOutake.linearHorizontal.upSetPoint();
        }
        if(gamepad2.dpad_left) {
            robot.intakeOutake.linearHorizontal.downSetPoint();
        }
        runningActions.add(robot.intakeOutake.linearHorizontal.handleHorizontalTeleop(getRuntime()));
        //telemetry.addData("Posição Alvo Horizontal", robot.intakeOutake.linearHorizontal.targetPositionLinearHorizontal);
        //telemetry.addData("Posição Linear Horizontal", robot.intakeOutake.linearHorizontal.motorLinearHorizontal.getCurrentPosition());
        //telemetry.addData("Velocidade LinearH", robot.intakeOutake.linearHorizontal.motorLinearHorizontal.getVelocity());
        /*=============*\
        |     Garra     |
        \*=============*/

        if(gamepad2.left_bumper) {
            runningActions.add(robot.intakeOutake.garra.gerenciadorDoFechamentoDaGarraNoTeleop(getRuntime()));
        }
        if (gamepad2.right_bumper) {
            runningActions.add(robot.intakeOutake.garra.gerenciadorDaRotacaoDaGarraNoTeleop(getRuntime()));
        }
        /*===================*\
        |     Braço Garra     |
        \*===================*/



        telemetry.addLine("=====  BRAÇO DA GARRA  =====");
        telemetry.addData("braço garra target", robot.intakeOutake.braco.targetPosition);
        telemetry.addData("braço garra posição", robot.intakeOutake.braco.getPosition());
        telemetry.addData("braço garra erro", robot.intakeOutake.braco.controladorDePosicao());
        telemetry.addData("braço garra correção", robot.intakeOutake.braco.correcao);
        telemetry.addData("braço garra velocidade", robot.intakeOutake.braco.motorBracoGarra.getVelocity());

        if (gamepad2.right_trigger > 0) {
            robot.intakeOutake.braco.upBraco(gamepad2.right_trigger);
            //telemetry.addData("a", "a");
        }
        if (gamepad2.left_trigger > 0) {
            robot.intakeOutake.braco.downBraco(gamepad2.left_trigger);
            //telemetry.addData("a", "b");
        }




        runningActions.add(robot.intakeOutake.braco.handleBracoTeleop(getRuntime()));
        /*======================*\
        |     HANDLE ACTIONS     |
        \*======================*/
        TelemetryPacket packet = new TelemetryPacket();
        // update running actions
        List<Action> newActions = new ArrayList<>();
        for (Action action : runningActions) {
            action.preview(packet.fieldOverlay());
            if (action.run(packet)) {
                newActions.add(action);
            }
        }
        runningActions = newActions;


        /*=============*\
        |    Testes     |
        \*=============*/

// Aumenta o ângulo, com limite
        if (gamepad1.dpad_right) {
            if (angulosServosTestado[portaServoSendoTestado] < 1.0) {  // Limite máximo
                angulosServosTestado[portaServoSendoTestado] += 0.025;
                servos.get(portaServoSendoTestado).setPosition(angulosServosTestado[portaServoSendoTestado]);
            }
        }

// Diminui o ângulo, com limite
        if (gamepad1.dpad_left) {
            if (angulosServosTestado[portaServoSendoTestado] > 0.025) {  // Limite mínimo
                angulosServosTestado[portaServoSendoTestado] -= 0.025;
                servos.get(portaServoSendoTestado).setPosition(angulosServosTestado[portaServoSendoTestado]);
            }
        }

        /* Muda a porta que está sendo alterada do servo */
        if(gamepad1.start) {
            if ( getRuntime() >=  cooldownChangePortaServo) {
                cooldownChangePortaServo = getRuntime() + 0.3;
                if (portaServoSendoTestado < 4) {
                    portaServoSendoTestado++;
                }
                else {
                    portaServoSendoTestado = 0;
                }
            }



        }

        /* Mostra os dados dos testes */

       // telemetry.addLine("==== TESTES DE SERVO ====");
       // telemetry.addData("Porta do servo", nomesServosTestados[portaServoSendoTestado]);
       // telemetry.addData("Angulo do servo", angulosServosTestado[portaServoSendoTestado]);
       // telemetry.addLine("============================");
       // telemetry.addData("TESTE COD ERRO",velocityVerify());
       telemetry.addData("Red", red);
       telemetry.addData("Green", green);
       telemetry.addData("Blue", blue);
       telemetry.addData("alpha", colorSensor.alpha());

        dashboard.sendTelemetryPacket(packet);
        telemetry.update();
    }




    private V2 createRobot(HardwareMap hardwareMap) {


        V2 robot = new V2(hardwareMap, telemetry);
        //MecanumDrive.PARAMS.maxProfileAccel = 30;
        robot.md.rightFront.setDirection(DcMotorSimple.Direction.FORWARD);

        return  robot;

    }

    private void robotCentricDrive(V2 robot)  {

        drive = Range.clip(-gamepad1.left_stick_y, -1, 1);
        //if( Math.abs(drive) < 0.8 && Math.abs(drive) > 0.02  ) drive = (drive / 1.5);

        strafe = Range.clip(-gamepad1.left_stick_x, -1, 1);
        if ( gamepad1.right_stick_button ) strafe = -0.6;
        if ( gamepad1.left_stick_button ) strafe = 0.6;
        //if ( Math.abs(strafe) < 0.8 && Math.abs(strafe) > 0.02 ) strafe = (strafe / 2.5);

        turn = -gamepad1.right_stick_x;
        if ( gamepad1.left_trigger > 0 ) {
            turn = -gamepad1.left_trigger;
        }

        if ( gamepad1.right_trigger > 0 )  {
            turn = gamepad1.right_trigger;
        }

        turn =   Range.clip(turn / 1.3, -0.7, 0.7);

        robot.md.setDrivePowers(new PoseVelocity2d(new Vector2d(drive, strafe), turn));

        //Ramp

/*
        if(Math.abs(gamepad1.left_stick_y) >0.1 ) {
            if (CurrentSpeed < MaxSpeed) {
                CurrentSpeed += SmAcceleration;
            }
            CurrentSpeed = Math.min(CurrentSpeed, MaxSpeed);
        }
        else{
            if (CurrentSpeed > 0.0) {
                CurrentSpeed = 0;
            }
        }
*/

        robot.md.updatePoseEstimate();

    }

    private void changeMode() {


    }
    public double velocityVerify() {
        // Capturar posição inicial do encoder
        int initialSpace = robot.intakeOutake.linearVertical.motorR.getCurrentPosition();
        int lastSpace =initialSpace; // Ajustado para refletir a posição inicial
        int deltaSpace;

        // Variável para armazenar o último tempo registrado
        double lastTime = getRuntime();
        double deltaTime;


        // Atualizar posição e tempo
        int currentSpace = robot.intakeOutake.linearVertical.motorR.getCurrentPosition();
        double currentTime = getRuntime();

        // Calcular variações
        deltaSpace = currentSpace - lastSpace;
        deltaTime = currentTime;



        // Calcular velocidade e aceleração
        double currentVelocity = (double) deltaSpace / getRuntime();
        double acceleration = currentVelocity / getRuntime();

        // Atualizar variáveis para próxima iteração
        lastSpace = currentSpace;
        lastTime = currentTime;

        // Ação caso aceleração seja negativa
        return currentVelocity ;

    }
}

