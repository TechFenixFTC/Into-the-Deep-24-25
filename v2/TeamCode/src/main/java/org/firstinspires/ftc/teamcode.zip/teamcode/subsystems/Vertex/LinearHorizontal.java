package org.firstinspires.ftc.teamcode.subsystems.Vertex;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.acmerobotics.roadrunner.InstantAction;
import com.arcrobotics.ftclib.controller.PIDController;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.Servo;
import com.arcrobotics.ftclib.util.Timing.Timer;
import com.qualcomm.robotcore.util.ElapsedTime;
@Config
public class LinearHorizontal {
    public Servo servoLinearHorizonal;
    public DcMotorEx motorLinearHorizontal;
    public int targetPositionLinearHorizontal = 0;

    public boolean precisaTerminarDeExtender = false, precisaTerminarDeRetrair = false;
    private double delayHoriontal = 0;

    public static double kp = 0.001, kd = 0.000, kff = 0.0000, kll = 0.0000;

    public LinearHorizontal(HardwareMap hardwareMap) {
        this.servoLinearHorizonal = hardwareMap.get(Servo.class, "porta4");
        this.motorLinearHorizontal = hardwareMap.get(DcMotorEx.class, "linearH");
        this.motorLinearHorizontal.setDirection(DcMotorSimple.Direction.REVERSE);
        this.motorLinearHorizontal.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        reset();

    }

    public void upSetPoint() {
        //if( this.targetPositionLinearHorizontal > 0.99) return;
        //this.targetPositionLinearHorizontal += 0.05;
        //this.servoLinearHorizonal.setPosition(targetPositionLinearHorizontal);
        //  if( this.targetPositionLinearHorizontal >  80) return;
        this.targetPositionLinearHorizontal += 180;
    }

    public void downSetPoint() {

        //this.targetPositionLinearHorizontal -= 0.05;
        //this.servoLinearHorizonal.setPosition(targetPositionLinearHorizontal);

        this.targetPositionLinearHorizontal -= 180;
    }
    public void reset() {
        targetPositionLinearHorizontal = 0;
        motorLinearHorizontal.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorLinearHorizontal.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }
    public Action recolher(double runTime, double delay) {

        if (delay > 0) {
            precisaTerminarDeRetrair = true;
            delayHoriontal = runTime + delay;
            return new InstantAction(() -> {});
        }
        return new Action() {
            int margin;
            //Timer timer = new Timer();
            ElapsedTime time = new ElapsedTime();

            boolean started = false;
            @Override
            public boolean run(@NonNull TelemetryPacket telemetryPacket) {
                if(!started) {
                    targetPositionLinearHorizontal = 0;
                    time.reset();
                    started = true;
                }


                margin  = 100;

                double positionError = controladorDePosicao();
                if (time.milliseconds() > 200 && Math.abs(motorLinearHorizontal.getVelocity()) < 25 ) {
                    reset();
                    return false;
                }
                return Math.abs(positionError) > margin;
            }

        };


    }
    public Action extender(double runTime, double delay) {
        if (delay > 0) {
            precisaTerminarDeExtender = true;
            delayHoriontal = runTime + delay;
            return new InstantAction(() -> {});
        }
        return new Action() {
            int margin;
            ElapsedTime time = new ElapsedTime();
            boolean started = false;
            @Override
            public boolean run(@NonNull TelemetryPacket telemetryPacket) {
                if(!started) {
                    time.reset();
                    targetPositionLinearHorizontal = 3100;
                    started = true;
                }


                margin  = 200;

                double positionError = controladorDePosicao();
                if((time.time() >  0.6 && Math.abs(motorLinearHorizontal.getVelocity()) < 15) || time.time() > 1){

                    return false;
                }
                return Math.abs(positionError) > margin;
            }

        };


    }
    public Action extenderNemTanto(double runTime, double delay) {
        if (delay > 0) {
            precisaTerminarDeExtender = true;
            delayHoriontal = runTime + delay;
            return new InstantAction(() -> {});
        }
        return new Action() {
            int margin;
            ElapsedTime time = new ElapsedTime();
            boolean started = false;
            @Override
            public boolean run(@NonNull TelemetryPacket telemetryPacket) {
                if(!started) {
                    time.reset();
                    targetPositionLinearHorizontal = 2000;
                    started = true;
                }


                margin  = 200;

                double positionError = controladorDePosicao();
                if((time.time() >  0.6 && Math.abs(motorLinearHorizontal.getVelocity()) < 15) || time.time() > 1){

                    return false;
                }
                return Math.abs(positionError) > margin;
            }

        };


    }
    public Action intake(double runTime, double delay) {
        if (delay > 0) {
            precisaTerminarDeExtender = true;
            delayHoriontal = runTime + delay;
            return new InstantAction(() -> {});
        }
        return new Action() {
            int margin;
            ElapsedTime time = new ElapsedTime();
            boolean started = false;
            @Override
            public boolean run(@NonNull TelemetryPacket telemetryPacket) {
                if(!started) {
                    time.reset();
                    targetPositionLinearHorizontal = 1200;
                    started = true;
                }


                margin  = 200;

                double positionError = controladorDePosicao();
                if((time.time() >  0.6 && Math.abs(motorLinearHorizontal.getVelocity()) < 15) || time.time() > 1){

                    return false;
                }
                return Math.abs(positionError) > margin;
            }

        };}

    public double controladorDePosicao() {

        // FeedForward

        double ff = targetPositionLinearHorizontal  * kff;

        //KP
        double p = kp;

        //Cria o Controlador PID
        PIDController controller = new PIDController(kp, 0, kd);
        controller.setPID(kp, 0, kd);

        //


        //Calcular correção
        double pid = controller.calculate(this.motorLinearHorizontal.getCurrentPosition(), targetPositionLinearHorizontal);

        if(motorLinearHorizontal.getCurrentPosition() < 0 && targetPositionLinearHorizontal < 0) {
            this.motorLinearHorizontal.setPower(0);
            return controller.getPositionError();
        }

        this.motorLinearHorizontal.setPower(pid + ff);

        return controller.getPositionError();

    }

    public Action handleHorizontalTeleop(double runTime) {

        if (precisaTerminarDeExtender && runTime >= delayHoriontal) {
            precisaTerminarDeExtender = false;
            return extender(runTime, 0);
        }
        if (precisaTerminarDeRetrair && runTime >= delayHoriontal) {
            precisaTerminarDeRetrair = false;
            return recolher(runTime, 0);
        }
        controladorDePosicao();
        return new InstantAction(() -> {});
    }

    /*===========================*\
                GETTERS
     /*===========================*/

}
